from django.apps import AppConfig


class TeamModelConfig(AppConfig):
    name = 'teamModel'
